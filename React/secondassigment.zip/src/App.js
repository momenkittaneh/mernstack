import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>HELLO DOJO!</h1>
        <h2>THINGS I NEED TO DO:</h2>
        <li>Learn React</li>
        <li>Climb Mt.Everest</li>
        <li>Run a marathon</li>
        <li>feed the dogs</li>

      </header>
    </div>
  );
}

export default App;
